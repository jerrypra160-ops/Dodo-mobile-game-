const arena=document.getElementById('arena'),player=document.getElementById('player');
const scoreEl=document.getElementById('score'),bestEl=document.getElementById('best'),message=document.getElementById('message');
let x=.5, score=0, best=Number(localStorage.dodoBest||0), running=false, speed=2.4, rocks=[], last=0, spawn=0, raf;
bestEl.textContent=best;

function move(dir){if(!running)return;x=Math.max(.1,Math.min(.9,x+dir*.055));player.style.left=(x*100)+'%'}
document.getElementById('left').onpointerdown=()=>move(-1);
document.getElementById('right').onpointerdown=()=>move(1);
window.onkeydown=e=>{if(e.key==='ArrowLeft'||e.key==='a')move(-1);if(e.key==='ArrowRight'||e.key==='d')move(1);if(e.key===' '&&!running)start()};

function start(){
  rocks.forEach(r=>r.el.remove()); rocks=[]; score=0; speed=2.4; x=.5; spawn=0; last=performance.now(); running=true;
  scoreEl.textContent=0; message.style.display='none'; cancelAnimationFrame(raf); raf=requestAnimationFrame(loop);
}
document.getElementById('start').onclick=start;

function addRock(){
 const el=document.createElement('div'); el.className='rock'; el.textContent=['🪨','🌵','🪵'][Math.floor(Math.random()*3)];
 el.style.left=(8+Math.random()*84)+'%'; el.style.top='-55px'; arena.appendChild(el);
 rocks.push({el,y:-55,x:parseFloat(el.style.left),size:38});
}
function loop(t){
 if(!running)return;
 const dt=Math.min(32,t-last); last=t; spawn+=dt; score+=dt*.01; scoreEl.textContent=Math.floor(score);
 speed=2.4+score/100;
 if(spawn>Math.max(260,850-score*2)){addRock();spawn=0}
 const pr=player.getBoundingClientRect(), ar=arena.getBoundingClientRect();
 for(let i=rocks.length-1;i>=0;i--){
   const r=rocks[i]; r.y+=speed*dt; r.el.style.top=r.y+'px';
   const rr=r.el.getBoundingClientRect();
   if(rr.bottom>pr.top+8&&rr.top<pr.bottom-8&&rr.right>pr.left+8&&rr.left<pr.right-8){gameOver();return}
   if(r.y>arena.clientHeight+60){r.el.remove();rocks.splice(i,1)}
 }
 raf=requestAnimationFrame(loop);
}
function gameOver(){
 running=false; cancelAnimationFrame(raf); const s=Math.floor(score);
 if(s>best){best=s;localStorage.dodoBest=best;bestEl.textContent=best}
 message.innerHTML=`GAME OVER!<br>Score: ${s}<br><small>Tap START to play again</small>`; message.style.display='grid';
}
